# build-autonomous-agent
description: Add an autonomous agent that calls tools in a bounded loop until it reaches an outcome.
options:
  argument-hint: "[agent-name]"

### Body

1. Add a step of `kind: AutonomousAgent`. Unlike `kind: agent` (one LLM call), it
   loops: the model picks tools, observes the results, and re-decides until done.
2. Declare the tools — each `ref` names ANOTHER step in the same workflow (an
   `api_call` / `mcp` / `model-op` / `functional`). Give each a clear
   `description` (the model uses it to choose) and a `parameters` JSON Schema:
   ```yaml
   - id: triage_agent
     kind: AutonomousAgent
     agent:
       model: default
       goal: "Resolve the customer ticket using the available tools."
       max_iterations: 8          # hard cap (default 8)
       token_budget: 50000        # OPTIONAL cap on cumulative tokens
       tools:
         - ref: lookup_order
           description: "Fetch order details by order id."
           parameters:
             type: object
             properties: { order_id: { type: string } }
             required: [order_id]
         - ref: issue_refund
           description: "Issue a refund for an order id and amount."
       outcome:
         enum: [resolved, escalate, needs_human]   # the closed set of exits
         output_key: agent_result                  # the single data output
     routes:
       resolved:        format_reply
       escalate:        notify_manager
       needs_human:     hitl_review
       max_iterations:  fallback_summary           # reserved abnormal exits
       error:           alert_ops
       budget_exceeded: fallback_summary
   ```
3. **Every** `outcome.enum` value MUST be mapped in `routes:`, plus the reserved
   abnormal exits `max_iterations` / `budget_exceeded` / `error`.
4. The agent reads context and writes only `output_key`. Tool results return to
   the agent; set `writes_context: true` on a tool only if it should also mutate
   the shared workflow context.
5. For data-driven branching after an outcome (e.g. by country), route into a
   deterministic `router` with `match:` — NEVER push that logic into the agent:
   ```yaml
   - id: route_by_country
     kind: router
     match: { field: user.country }
     routes: { US: resolve_us, DE: resolve_eu, default: resolve_other }
   ```
